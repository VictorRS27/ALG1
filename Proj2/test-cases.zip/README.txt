Arquivo zip gerado em: 21/12/2021 10:52:41 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Projeto 2 - Árvores Treaps