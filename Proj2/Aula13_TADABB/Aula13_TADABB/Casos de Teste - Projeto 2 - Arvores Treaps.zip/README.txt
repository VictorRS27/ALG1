Arquivo zip gerado em: 15/12/2021 23:46:31 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Projeto 2 - Árvores Treaps