Arquivo zip gerado em: 21/12/2021 10:45:55 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 7