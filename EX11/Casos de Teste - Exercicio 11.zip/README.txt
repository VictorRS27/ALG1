Arquivo zip gerado em: 02/12/2021 18:53:25 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 11