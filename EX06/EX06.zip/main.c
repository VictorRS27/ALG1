#include <stdio.h>
#include <stdlib.h>
#include "list.h"

int main(int argc, char const *argv[])
{
    int i, j, times, size, rotations, number;
    list_t *numbers;

    numbers = create();

    scanf("%i", &times);

    for (i = 0; i < times; i++)
    {
        scanf(" %i", &size);
        scanf(" %i", &rotations);
        for ( j = 0; j < size; j++)
        {
            scanf(" %i", &number);
            insert(numbers, number);
        }
        rotate_left(numbers, rotations);
        print(numbers);
        printf("\n");
        clear(numbers);
    }

    destroy(numbers);
    
    return 0;
}
